import ProductDetail from '../components/ProductDetail';

const ProductPage = () => {
  return <ProductDetail />;
};

export default ProductPage;